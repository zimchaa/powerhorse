#ifndef __MAIN_H__
#define __MAIN_H__

#include <stdio.h>      //printf()
#include <stdlib.h>     //exit()
#include <signal.h>

#include "DEV_Config.h"
#include <time.h>
#include "DEV_Config.h"
#include "MotorDriver.h"

#endif 